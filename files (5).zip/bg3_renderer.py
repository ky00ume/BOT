"""
bg3_renderer.py — 발더스게이트3 스타일 PIL 렌더링 엔진 (최종)
비전 타운 봇 전용 디자인 시스템

에셋 경로 규칙:
  초상화:  static/portraits/{npc|animal|monster}/{id}.png
  스탯 아이콘: static/icons/stat/{str|dex|int|will|luck}.png
  배너:    static/banners/{town|hunting|gathering|fishing}/{zone_id}.png|.webp
  → 파일이 없으면 플레이스홀더 자동 표시, 레이아웃 미붕괴 보장
"""
import io, os, math
from typing import Optional
try:
    from PIL import Image, ImageDraw, ImageFont, ImageFilter
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

# ══════════════════════════════════════════════════════════════════
# 경로
# ══════════════════════════════════════════════════════════════════
_BASE    = os.path.dirname(os.path.abspath(__file__))
_STATIC  = os.path.join(_BASE, "static")
_PORT_D  = os.path.join(_STATIC, "portraits")
_ICON_D  = os.path.join(_STATIC, "icons", "stat")
_BAN_D   = os.path.join(_STATIC, "banners")

_FONT_KR  = "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc"
_FONT_KRB = "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc"
_FONT_LO  = "/usr/share/fonts/truetype/google-fonts/Lora-Variable.ttf"
_FONT_SB  = "/usr/share/fonts/truetype/liberation/LiberationSerif-Bold.ttf"

_FC: dict = {}

def _f(size: int, bold: bool = False):
    k = (size, bold)
    if k in _FC: return _FC[k]
    for p in ([_FONT_KRB, _FONT_SB, _FONT_LO] if bold
              else [_FONT_KR, _FONT_LO, _FONT_SB]):
        try:
            font = ImageFont.truetype(p, size)
            _FC[k] = font; return font
        except: pass
    font = ImageFont.load_default(); _FC[k] = font; return font

def _tw(d, t, f) -> int:
    try: bb = d.textbbox((0,0), t, font=f); return bb[2]-bb[0]
    except: return len(t) * max(7, getattr(f,"size",12)//2)

def _th(d, t, f) -> int:
    try: bb = d.textbbox((0,0), t, font=f); return bb[3]-bb[1]
    except: return getattr(f,"size",12)


# ══════════════════════════════════════════════════════════════════
# 에셋 로더
# ══════════════════════════════════════════════════════════════════

def _load_portrait(portrait_type: str, portrait_id: str,
                   w: int, h: int) -> Optional[Image.Image]:
    """
    초상화 로드 및 크롭.
    portrait_type: 'npc' | 'animal' | 'monster'
    portrait_id:   파일명 (확장자 제외)
    없으면 None 반환 → 호출부에서 플레이스홀더 처리
    """
    folder = os.path.join(_PORT_D, portrait_type)
    for ext in (".png", ".webp", ".jpg", ".jpeg"):
        p = os.path.join(folder, portrait_id + ext)
        if os.path.isfile(p):
            try:
                img = Image.open(p).convert("RGBA")
                # 얼굴 중심 크롭 (상단 1/4 기준)
                ir, br = img.width / img.height, w / h
                if ir > br:
                    nh = h; nw = int(h * ir)
                    img = img.resize((nw, nh), Image.LANCZOS)
                    cx = (nw - w) // 2
                    img = img.crop((cx, 0, cx+w, nh))
                else:
                    nw = w; nh = int(w / ir)
                    img = img.resize((nw, nh), Image.LANCZOS)
                    cy = nh // 6
                    img = img.crop((0, cy, nw, cy+h))
                return img
            except: pass
    return None


def _load_stat_icon(stat_key: str, size: int) -> Optional[Image.Image]:
    """
    스탯 아이콘 로드.
    static/icons/stat/{stat_key}.png
    없으면 None → 호출부에서 다이아몬드 플레이스홀더
    """
    for ext in (".png", ".webp"):
        p = os.path.join(_ICON_D, stat_key + ext)
        if os.path.isfile(p):
            try:
                img = Image.open(p).convert("RGBA")
                return img.resize((size, size), Image.LANCZOS)
            except: pass
    return None


def _load_banner(zone_type: str, zone_id: str,
                 w: int, h: int) -> Optional[Image.Image]:
    """
    배너 씬 이미지 로드 및 크롭.
    zone_type: 'town' | 'hunting' | 'gathering' | 'fishing'
    zone_id:   파일명 (확장자 제외, 예: '비전타운', '고블린동굴')
    없으면 None → 호출부에서 플레이스홀더 처리
    """
    folder = os.path.join(_BAN_D, zone_type)
    for ext in (".png", ".webp", ".jpg", ".jpeg"):
        p = os.path.join(folder, zone_id + ext)
        if os.path.isfile(p):
            try:
                img = Image.open(p).convert("RGBA")
                ir, br = img.width / img.height, w / h
                if ir > br:
                    nh = h; nw = int(h * ir)
                    img = img.resize((nw, nh), Image.LANCZOS)
                    cx = (nw - w) // 2
                    img = img.crop((cx, 0, cx+w, nh))
                else:
                    nw = w; nh = int(w / ir)
                    img = img.resize((nw, nh), Image.LANCZOS)
                    img = img.crop((0, 0, nw, h))
                return img
            except: pass
    return None


# ══════════════════════════════════════════════════════════════════
# 색상 팔레트
# ══════════════════════════════════════════════════════════════════
class C:
    BG0 = (8,7,18);   BG1 = (14,12,28); BG2 = (20,18,38); BG3 = (28,24,50)
    GOLD_HI  = (235,200,110); GOLD_MID = (195,158,78); GOLD_LO = (130,100,42)
    GOLD_GL  = (255,225,130,55)
    TXT_HI   = (245,238,222); TXT_MID  = (195,186,168); TXT_LO  = (128,118,102)
    TXT_LBL  = (148,138,122)
    TEAL_HI  = (88,220,210);  TEAL_MID = (52,168,160);  TEAL_LO = (28,100,96)
    SEP      = (52,48,68)
    RARITY = {
        "Normal":   (155,155,155), "Rare":      (80,155,230),
        "Epic":     (160,90,255),  "Legendary": (245,200,45),
        "Fail":     (220,65,55),
    }
    RARITY_GL = {
        "Normal":   (50,50,50,35),   "Rare":      (25,70,150,45),
        "Epic":     (70,25,130,50),  "Legendary": (155,105,0,55),
        "Fail":     (115,15,8,45),
    }
    SYS = {
        "battle":  (155,25,42),  "npc":    (48,125,78),
        "shop":    (180,150,28), "status": (78,122,190),
        "quest":   (180,115,32), "rest":   (82,82,185),
        "system":  (60,52,80),   "fishing":(30,115,150),
        "cooking": (160,90,30),  "craft":  (80,110,150),
    }
    # 바 색상: (기본, 하이라이트)
    HP  = ((195,52,52),  (255,95,75))
    MP  = ((50,88,195),  (95,145,255))
    EN  = ((42,162,70),  (85,215,95))
    EXP = ((48,162,155), (82,215,205))
    BAR_BG = (8,7,18); BAR_FR = (140,110,45)


# ══════════════════════════════════════════════════════════════════
# 저수준 드로잉 유틸
# ══════════════════════════════════════════════════════════════════

def _gv(img, x0,y0,x1,y1, ct, cb, at=255, ab=255):
    """수직 그라디언트"""
    d = ImageDraw.Draw(img); h = y1-y0
    if h <= 0: return
    r0,g0,b0=ct[:3]; r1,g1,b1=cb[:3]
    for dy in range(h):
        t = dy/max(h-1,1)
        r=int(r0+(r1-r0)*t); g=int(g0+(g1-g0)*t); b=int(b0+(b1-b0)*t)
        a=int(at+(ab-at)*t)
        d.line([(x0,y0+dy),(x1,y0+dy)], fill=(r,g,b,a))

def _rr(img, x0,y0,x1,y1, rad, fill=None, outline=None, lw=1):
    """RGBA 둥근 사각형"""
    ov = Image.new("RGBA", img.size, (0,0,0,0))
    d  = ImageDraw.Draw(ov)
    if fill:   d.rounded_rectangle([x0,y0,x1,y1], radius=rad, fill=fill)
    if outline: d.rounded_rectangle([x0,y0,x1,y1], radius=rad, outline=outline, width=lw)
    img.alpha_composite(ov)

def _glow(img, x0,y0,x1,y1, color, rad=0, blur=8):
    """글로우"""
    g = Image.new("RGBA", img.size, (0,0,0,0))
    r,gc,b = color[:3]; a = color[3] if len(color)>3 else 70
    if rad == 0:
        ImageDraw.Draw(g).rectangle([x0,y0,x1,y1], fill=(r,gc,b,a))
    else:
        ImageDraw.Draw(g).rounded_rectangle([x0,y0,x1,y1], radius=rad, fill=(r,gc,b,a))
    g = g.filter(ImageFilter.GaussianBlur(blur))
    img.alpha_composite(g)

def _gold_frame(img, radius=16):
    """BG3 금장 3중 테두리 + 코너 다이아몬드"""
    w,h = img.size; d = ImageDraw.Draw(img)
    _glow(img, 2,2,w-3,h-3, C.GOLD_GL, rad=radius+2, blur=6)
    d.rounded_rectangle([1,1,w-2,h-2], radius=radius, outline=C.GOLD_HI, width=2)
    d.rounded_rectangle([5,5,w-6,h-6], radius=max(radius-4,4), outline=C.GOLD_LO, width=1)
    S = 9
    for cx,cy in [(2,2),(w-3,2),(2,h-3),(w-3,h-3)]:
        d.polygon([(cx,cy-S),(cx+S,cy),(cx,cy+S),(cx-S,cy)], fill=C.GOLD_HI)
        s2 = S//2
        d.polygon([(cx,cy-s2),(cx+s2,cy),(cx,cy+s2),(cx-s2,cy)], fill=C.BG0)

def _orn(img, d, x0,y,x1, color=None, thick=1):
    """장식 구분선"""
    col = color or C.GOLD_MID
    d.line([(x0+12,y),(x1-12,y)], fill=col, width=thick)
    for cx in [x0+7, x1-7]:
        d.polygon([(cx,y-4),(cx+4,y),(cx,y+4),(cx-4,y)], fill=col)

def _notxt(d, pos, text, font, fill):
    """이모지 제외 텍스트 (깨짐 방지)"""
    clean = ""
    for ch in text:
        cp = ord(ch)
        if (0x1F000<=cp<=0x1FFFF or 0x2600<=cp<=0x27BF or 0x2300<=cp<=0x23FF):
            clean += " "
        else:
            clean += ch
    d.text(pos, clean, font=font, fill=fill)

def _wrap(d, text, font, x,y, maxw, fill, lh=21) -> int:
    """자동 줄바꿈, 마지막 y 반환"""
    line = ""; cy = y
    for ch in text:
        test = line+ch
        if _tw(d,test,font) > maxw and line:
            _notxt(d,(x,cy), line, font, fill); cy+=lh; line=ch
        else: line = test
    if line: _notxt(d,(x,cy), line, font, fill); cy+=lh
    return cy

def _make_base(w,h, sys_key="system", grade="Normal") -> Image.Image:
    """카드 베이스 배경 생성"""
    img = Image.new("RGBA",(w,h),(0,0,0,0))
    _gv(img,0,0,w,h, C.BG1,C.BG0)
    sc = C.SYS.get(sys_key, C.SYS["system"])
    _glow(img,0,h//2,w,h, sc, rad=0, blur=45)
    rc = C.RARITY.get(grade,(60,60,60))
    _glow(img,0,0,w,h//3, rc, rad=0, blur=30)
    # 미묘한 대각선 광택
    ov = Image.new("RGBA",(w,h),(0,0,0,0)); dp = ImageDraw.Draw(ov)
    for i in range(0,w+h,60):
        dp.line([(i,0),(0,i)], fill=(255,255,255,4), width=1)
    img.alpha_composite(ov)
    # 둥근 마스크
    mk = Image.new("L",(w,h),0)
    ImageDraw.Draw(mk).rounded_rectangle([0,0,w-1,h-1], radius=16, fill=255)
    r = Image.new("RGBA",(w,h),(0,0,0,0)); r.paste(img, mask=mk)
    return r

def _to_buf(img) -> io.BytesIO:
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "PNG", optimize=True)
    buf.seek(0); return buf


# ══════════════════════════════════════════════════════════════════
# ★ 게이지 바 — 시안 A (세그먼트 노치, 최종 확정)
# ══════════════════════════════════════════════════════════════════

def _bar_A(img, d, x,y, w,h, cur,mx, colors, label="", show_val=True):
    """
    BG3 스타일 세그먼트 바 (시안 A 확정)
    - 좌→우 밝아지는 그라디언트
    - 10% 간격 수직 노치
    - 상단 하이라이트 + 하단 그림자
    - 이중 금색 외부 프레임
    """
    ratio = max(0.0, min(1.0, cur/max(mx,1)))
    bc, hc = colors
    r,g,b  = bc
    fw     = int(w*ratio)

    # ① 이중 외부 프레임
    d.rectangle([x-2,y-2,x+w+2,y+h+2], outline=(140,110,45), width=1)
    d.rectangle([x-1,y-1,x+w+1,y+h+1], outline=(80,60,20),   width=1)

    # ② 배경 홈
    d.rectangle([x,y,x+w,y+h], fill=C.BAR_BG)

    # ③ 채움 그라디언트 (좌→우)
    if fw > 0:
        for px in range(fw):
            t  = px/max(fw-1,1)
            cr = int(r*0.65 + r*0.35*t)
            cg = int(g*0.65 + g*0.35*t)
            cb2= int(b*0.65 + b*0.35*t)
            d.line([(x+px,y+1),(x+px,y+h-1)], fill=(cr,cg,cb2))

        # ④ 상단 하이라이트 (밝은 수평 선)
        hr,hg,hb = hc
        for px in range(fw):
            t2 = px/max(fw-1,1)
            a2 = int(190*(1-t2*0.4))
            d.point((x+px, y+1),  fill=(hr,hg,hb))
            d.point((x+px, y+2),  fill=(hr,hg,hb,a2//2))

        # ⑤ 하단 그림자 선
        for px in range(fw):
            d.point((x+px, y+h-1), fill=(r//3, g//3, b//3))

        # ⑥ 세그먼트 노치 (10% 간격)
        seg = max(1, w//10)
        for i in range(1,10):
            nx = x + seg*i
            if nx < x+fw:
                d.line([(nx,y+1),(nx,y+h-1)], fill=(0,0,0,130), width=1)

    # ⑦ 내부 테두리 마무리
    d.rectangle([x,y,x+w,y+h], outline=(55,48,72), width=1)

    # ⑧ 라벨 (좌측)
    if label:
        fl = _f(max(10, h-4), bold=True)
        lw = _tw(d, label, fl)
        d.text((x-lw-10, y+h//2-_th(d,"0",fl)//2), label,
               font=fl, fill=C.TXT_LBL)

    # ⑨ 수치 (우측)
    if show_val:
        fv  = _f(max(9, h-5))
        txt = f"{cur}/{mx}"
        d.text((x+w+8, y+h//2-_th(d,"0",fv)//2), txt,
               font=fv, fill=C.TXT_MID)


# ══════════════════════════════════════════════════════════════════
# 등급 배지 — 자간 균일 고정폭
# ══════════════════════════════════════════════════════════════════

def _grade_badge(img, d, x,y, grade) -> int:
    labels = {
        "Normal":"NORMAL","Rare":"RARE","Epic":"EPIC",
        "Legendary":"LEGENDARY","Fail":"FAIL"
    }
    txt = labels.get(grade, grade.upper())
    col = C.RARITY.get(grade,(155,155,155))
    gl  = C.RARITY_GL.get(grade,(50,50,50,35))
    f   = _f(12, bold=True)
    CW=10; PAD=9
    bx0=x; by0=y; bx1=x+len(txt)*CW+PAD*2; by1=y+22
    _glow(img,bx0-3,by0-3,bx1+3,by1+3, (*gl[:3],gl[3]), rad=6, blur=5)
    _rr(img,bx0,by0,bx1,by1, 4, fill=(*C.BG2,210), outline=col, lw=1)
    d  = ImageDraw.Draw(img)
    cx = bx0+PAD
    for ch in txt:
        cw  = _tw(d,ch,f); off=(CW-cw)//2
        d.text((cx+off,by0+5), ch, font=f, fill=col)
        cx += CW
    return bx1


# ══════════════════════════════════════════════════════════════════
# 초상화 플레이스홀더
# ══════════════════════════════════════════════════════════════════

def _ph_portrait(img, d, x0,y0,x1,y1):
    _rr(img,x0,y0,x1,y1, 8, fill=(*C.BG3,200))
    d  = ImageDraw.Draw(img)
    cx = (x0+x1)//2; cy=(y0+y1)//2
    r  = min((x1-x0),(y1-y0))//5
    d.ellipse([cx-r,cy-r*2,cx+r,cy-r//3],   fill=C.BG2, outline=C.GOLD_LO, width=1)
    d.ellipse([cx-r,cy-r//4,cx+r,cy+r+r//2], fill=C.BG2, outline=C.GOLD_LO, width=1)
    fp = _f(10)
    d.text((cx-_tw(d,"초상화 없음",fp)//2, cy+r+8), "초상화 없음", font=fp, fill=C.TXT_LO)


# ══════════════════════════════════════════════════════════════════
# 스탯 아이콘 플레이스홀더
# ══════════════════════════════════════════════════════════════════

def _paste_stat_icon(img, d, stat_key, x,y, size=24):
    """스탯 아이콘 붙여넣기. 없으면 다이아몬드 플레이스홀더"""
    ico = _load_stat_icon(stat_key, size)
    if ico:
        img.paste(ico,(x,y), ico)
        return True
    # 다이아몬드 플레이스홀더
    cx,cy = x+size//2, y+size//2; s=size//3
    d = ImageDraw.Draw(img)
    d.polygon([(cx,cy-s),(cx+s,cy),(cx,cy+s),(cx-s,cy)], fill=C.GOLD_MID)
    return False


# ══════════════════════════════════════════════════════════════════
# 렌더러 클래스
# ══════════════════════════════════════════════════════════════════

class BG3Renderer:

    # ─── 범용 카드 ───────────────────────────────────────────────
    def render_card(self, title, rows,
                    grade="Normal", subtitle=None,
                    system_key="system",
                    footer="✦ 비전 타운 ✦",
                    w=560, h=340) -> io.BytesIO:
        img = _make_base(w,h, system_key, grade)
        d   = ImageDraw.Draw(img)
        rc  = C.RARITY.get(grade,(155,155,155))
        fT  = _f(22,True); fS=_f(12); fL=_f(13); fV=_f(14,True); fF=_f(11)
        PAD = 22; HH = 60 if not subtitle else 78

        # 헤더 패널
        hdr = Image.new("RGBA",(w,h),(0,0,0,0))
        _gv(hdr,0,0,w,HH, (*C.BG3,225),(0,0,0,0))
        img.alpha_composite(hdr); d=ImageDraw.Draw(img)

        _notxt(d,(PAD,13), title, fT, C.TXT_HI)
        if subtitle: _notxt(d,(PAD+1,44), subtitle, fS, C.TXT_LO)
        _grade_badge(img,d, w-145,12, grade)
        _orn(img,d, PAD,HH, w-PAD, color=rc)

        # 콘텐츠 패널
        FH=40; CT=HH+10; CB=h-FH-6
        _rr(img,PAD,CT,w-PAD,CB, 8, fill=(*C.BG2,115))
        d=ImageDraw.Draw(img)

        avail=CB-CT-14; rh=max(26,min(34,avail//max(len(rows),1)))
        mx_col=PAD+(w-PAD*2)*2//5+22; cy=CT+10

        for i,row in enumerate(rows):
            lbl = row.get("label",""); val=str(row.get("value",""))
            col = row.get("color", C.TXT_HI)
            if i>0: d.line([(PAD+16,cy-4),(w-PAD-16,cy-4)], fill=C.SEP, width=1)
            _notxt(d,(PAD+16,cy), lbl+":", fL, C.TXT_LBL)
            _notxt(d,(mx_col,cy), val,      fV, col)
            cy+=rh

        sy=h-FH; _orn(img,d,PAD,sy,w-PAD, color=C.GOLD_LO)
        fw=_tw(d,footer,fF); d.text((w//2-fw//2,sy+10), footer, font=fF, fill=C.TXT_LO)
        _gold_frame(img); return _to_buf(img)

    # ─── 상태창 ──────────────────────────────────────────────────
    def render_status_card(self,
                           name, level, title_str,
                           hp, max_hp, mp, max_mp, en, max_en,
                           gold, exp, exp_needed,
                           stats: dict,
                           inv_used, inv_max) -> io.BytesIO:
        W,H = 600,410
        img = _make_base(W,H,"status")
        d   = ImageDraw.Draw(img)
        fN=_f(26,True); fT=_f(13); fSec=_f(13,True)
        fSt=_f(13); fV=_f(15,True); fLb=_f(11)
        PAD=22; HH=74

        # 헤더
        hdr=Image.new("RGBA",(W,H),(0,0,0,0))
        _gv(hdr,0,0,W,HH, (*C.BG3,230),(0,0,0,0))
        img.alpha_composite(hdr); d=ImageDraw.Draw(img)
        _notxt(d,(PAD,12), f"Lv.{level}  {name}", fN, C.TXT_HI)
        _notxt(d,(PAD+2,48), f"✦ {title_str}", fT, C.GOLD_MID)
        _orn(img,d,PAD,HH,W-PAD)

        # ── 게이지 바 (시안 A) ──────────────────────────────
        BW=220; BH=20; BX=PAD+52; LX=PAD+4
        bars=[("HP",hp,max_hp,C.HP),("MP",mp,max_mp,C.MP),("EN",en,max_en,C.EN)]
        by = HH+22
        for lbl,cur,mx2,cols in bars:
            _notxt(d,(LX,by+2),lbl,fLb,C.TXT_LBL)
            _bar_A(img,d,BX,by,BW,BH,cur,mx2,cols,show_val=True)
            d=ImageDraw.Draw(img); by+=34

        _orn(img,d,PAD,by+4,W//2+60,color=C.GOLD_LO); by+=16
        _notxt(d,(LX,by+2),"EXP",fLb,C.TXT_LBL)
        _bar_A(img,d,BX,by,BW,BH,int(exp),exp_needed,C.EXP,show_val=True)
        d=ImageDraw.Draw(img)

        # ── 스탯 (오른쪽) ────────────────────────────────────
        RX=W//2+58; RY=HH+14
        _notxt(d,(RX,RY),"[ 기본 스탯 ]",fSec,C.GOLD_MID)
        _orn(img,d,RX,RY+22,W-PAD,color=C.GOLD_LO)

        STAT_DATA=[
            ("str","힘",  stats.get("str",0)),
            ("dex","민첩",stats.get("dex",0)),
            ("int","지력",stats.get("int",0)),
            ("will","의지",stats.get("will",0)),
            ("luck","운", stats.get("luck",0)),
        ]
        IS=24; sy=RY+32
        for sk,sname,val in STAT_DATA:
            _paste_stat_icon(img,d, sk, RX, sy-1, IS)
            d=ImageDraw.Draw(img)
            _notxt(d,(RX+IS+10,sy+4), sname, fSt, C.TXT_LBL)
            vt=str(val); vw=_tw(d,vt,fV)
            _notxt(d,(W-PAD-vw-6,sy+3), vt, fV, C.TXT_HI)
            # 점선 리더
            lx2=RX+IS+10+_tw(d,sname,fSt)+8; rx2=W-PAD-vw-14
            if rx2>lx2:
                for dx in range(lx2,rx2,7): d.point((dx,sy+IS//2),fill=C.SEP)
            sy+=32

        # 하단 골드/인벤
        _orn(img,d,PAD,H-56,W-PAD)
        _notxt(d,(PAD+16,H-44), f"{gold:,} G", fV, C.GOLD_HI)
        it=f"{inv_used} / {inv_max} 슬롯"
        _notxt(d,(W//2+22,H-44), it, fV, C.TXT_MID)
        _orn(img,d,PAD,H-18,W-PAD,color=C.GOLD_LO)

        _gold_frame(img); return _to_buf(img)

    # ─── NPC 대화 ────────────────────────────────────────────────
    def render_npc_dialogue(self,
                            npc_name, npc_role, greeting,
                            affinity_pts, affinity_level,
                            portrait_type="npc",
                            portrait_id=None) -> io.BytesIO:
        """
        portrait_type: 'npc' | 'animal' | 'monster'
        portrait_id:   파일명 (확장자 제외). None이면 플레이스홀더
        """
        W,H = 660,235
        img = _make_base(W,H,"npc")
        d   = ImageDraw.Draw(img)
        PW=172; fN=_f(19,True); fR=_f(12); fD=_f(13); fA=_f(12); fP=_f(11)
        PX0,PY0=14,14; PX1,PY1=PW-4,H-14
        pw2=PX1-PX0-2; ph2=PY1-PY0-2

        # 초상화
        _rr(img,PX0,PY0,PX1,PY1,8, fill=(*C.BG3,200))
        port = (_load_portrait(portrait_type, portrait_id, pw2, ph2)
                if portrait_id else None)
        if port:
            mk = Image.new("L",(pw2,ph2),0)
            ImageDraw.Draw(mk).rounded_rectangle([0,0,pw2-1,ph2-1],radius=6,fill=255)
            img.paste(port,(PX0+1,PY0+1), mk)
        else:
            _ph_portrait(img,d, PX0,PY0,PX1,PY1)

        d=ImageDraw.Draw(img)
        d.rounded_rectangle([PX0,PY0,PX1,PY1], radius=8, outline=C.GOLD_MID, width=2)

        # 대화창
        TX=PW+12; ty=16
        d.text((TX,ty), npc_name, font=fN, fill=C.GOLD_HI)
        d.text((TX+2,ty+27), f"[ {npc_role} ]", font=fR, fill=C.TXT_LO)
        _orn(img,d,TX,ty+48,W-16, color=C.GOLD_LO)
        _wrap(d, f'"{greeting}"', fD, TX, ty+58, W-TX-20, C.TXT_HI, lh=21)

        # 호감도 바 (시안 A)
        AY=H-48; _orn(img,d,TX,AY,W-16, color=(*C.TEAL_LO,180))
        d=ImageDraw.Draw(img)
        d.text((TX,AY+10), affinity_level, font=fA, fill=C.TEAL_HI)
        aw=_tw(d,affinity_level,fA)
        _bar_A(img,d, TX+aw+10, AY+10, W-TX-aw-60, 14,
               min(affinity_pts,100), 100,
               (C.TEAL_LO, C.TEAL_HI), show_val=False)
        d=ImageDraw.Draw(img)
        pt2=f"{affinity_pts}pt"; pw3=_tw(d,pt2,fP)
        d.text((W-pw3-16,AY+12), pt2, font=fP, fill=C.TXT_LO)

        _gold_frame(img); return _to_buf(img)

    # ─── 전투 카드 ───────────────────────────────────────────────
    def render_battle_card(self,
                           monster_name, monster_level,
                           monster_hp, monster_max_hp,
                           danger, turn,
                           player_hp, player_max_hp,
                           player_mp, player_max_mp,
                           last_action="", last_dmg=0,
                           is_crit=False, size_label="") -> io.BytesIO:
        W,H=560,310
        img=_make_base(W,H,"battle"); d=ImageDraw.Draw(img)
        fB=_f(20,True); fM=_f(14,True); fS=_f(12); fL=_f(11); PAD=20

        _notxt(d,(PAD,13), monster_name, fB, C.TXT_HI)
        _notxt(d,(PAD+2,42), f"Lv.{monster_level}   {size_label}", fS, C.TXT_LO)

        DCOL={"위험당함":(220,55,45),"보통":(230,180,30),"안전":(50,195,100)}
        dc=DCOL.get(danger,(155,155,155)); dt=f"  {danger}  "
        dw=_tw(d,dt,fS)
        _rr(img,W-dw-PAD-6,10,W-PAD+2,34,5, fill=(*dc,38),outline=dc,lw=1)
        d=ImageDraw.Draw(img); d.text((W-dw-PAD,14),dt, font=fS, fill=dc)

        rc=C.SYS["battle"]; _orn(img,d,PAD,56,W-PAD,color=rc)

        # 몬스터 HP (시안 A, 크게)
        _notxt(d,(PAD,68),"몬스터 HP",fL,C.TXT_LBL)
        _bar_A(img,d, PAD+82,66, W-PAD*2-82,24, monster_hp,monster_max_hp, C.HP)
        d=ImageDraw.Draw(img); _orn(img,d,PAD,104,W-PAD,color=(68,22,28))

        # 플레이어 HP/MP
        _notxt(d,(PAD,116),"내 HP",fL,C.TXT_LBL)
        _bar_A(img,d,PAD+62,114, 205,18, player_hp,player_max_hp, C.HP)
        d=ImageDraw.Draw(img)
        _notxt(d,(PAD,140),"내 MP",fL,C.TXT_LBL)
        _bar_A(img,d,PAD+62,138, 205,18, player_mp,player_max_mp, C.MP)
        d=ImageDraw.Draw(img); _orn(img,d,PAD,170,W-PAD,color=(68,22,28))

        # 마지막 액션
        if last_action:
            col=C.GOLD_HI if is_crit else C.TXT_HI
            pre="[크리티컬]  " if is_crit else ""
            _notxt(d,(PAD,180),f"{pre}{last_action}  /  {last_dmg} 피해",fM,col)
        tt=f"턴  {turn}"; tw2=_tw(d,tt,fS)
        d.text((W-tw2-PAD,182),tt, font=fS, fill=C.TXT_LO)

        _orn(img,d,PAD,H-46,W-PAD,color=rc)
        g="/공격 [스킬명]   /도주"; gw=_tw(d,g,fL)
        d.text((W//2-gw//2,H-34),g, font=fL, fill=C.TXT_LO)

        _gold_frame(img); return _to_buf(img)

    # ─── 장소 배너 ───────────────────────────────────────────────
    def render_location_banner(self,
                                location_name: str,
                                description: str,
                                zone_type: str = "town",
                                zone_id: str = None) -> io.BytesIO:
        """
        zone_type: 'town' | 'hunting' | 'gathering' | 'fishing'
        zone_id:   파일명 (확장자 제외, 예: '비전타운', '고블린동굴')
                   None이면 플레이스홀더 표시
        """
        W=700; SH=200; TH=148; H=SH+TH
        img=Image.new("RGBA",(W,H),(0,0,0,0))

        # ── 상단 씬 이미지 슬롯 ─────────────────────────────
        scene = (_load_banner(zone_type, zone_id, W, SH)
                 if zone_id else None)

        if scene:
            # 하단 페이드 아웃
            fd=Image.new("RGBA",(W,SH),(0,0,0,0))
            _gv(fd,0,SH*3//5,W,SH, (0,0,0,0),(0,0,0,210))
            scene.alpha_composite(fd)
            img.paste(scene,(0,0))
        else:
            # 플레이스홀더 (그라디언트 + 안내 텍스트)
            _gv(img,0,0,W,SH, C.BG2,C.BG0)
            d2=ImageDraw.Draw(img)
            d2.rounded_rectangle([16,16,W-17,SH-16], radius=8,
                                  outline=(*C.GOLD_LO,100), width=1)
            fph=_f(14)
            ph_type = {"town":"마을","hunting":"사냥터",
                       "gathering":"채집터","fishing":"낚시터"}.get(zone_type,"")
            ph=f"[ {ph_type} 씬 이미지 슬롯 ]"
            pw=_tw(d2,ph,fph)
            d2.text((W//2-pw//2,SH//2-9),ph, font=fph, fill=C.TXT_LO)

        # 씬 슬롯 테두리 표시
        d=ImageDraw.Draw(img)
        d.rounded_rectangle([14,14,W-15,SH-14], radius=8,
                             outline=(*C.GOLD_LO,80), width=1)

        # ── 하단 텍스트 패널 ────────────────────────────────
        tp=Image.new("RGBA",(W,H),(0,0,0,0))
        _gv(tp,0,SH,W,H, (*C.BG1,245),(*C.BG0,255))
        img.alpha_composite(tp); d=ImageDraw.Draw(img)

        fLoc=_f(28,True); fDesc=_f(13); fSub=_f(11)
        TY=SH+14
        # 금장 세로선
        d.line([(22,TY+2),(22,H-16)], fill=C.GOLD_MID,  width=3)
        d.line([(23,TY+2),(23,H-16)], fill=(*C.GOLD_HI,65), width=1)

        _notxt(d,(38,TY), location_name, fLoc, C.GOLD_HI)
        lw=_tw(d,location_name,fLoc)
        d.line([(38,TY+40),(38+lw,TY+40)], fill=C.GOLD_MID, width=1)
        _wrap(d,description,fDesc, 38,TY+50, W-56, C.TXT_MID, lh=19)

        sub="✦ 비전 타운   언더다크"; sw=_tw(d,sub,fSub)
        d.text((W-sw-18,H-22),sub, font=fSub, fill=C.TXT_LO)

        # 전체 마스크
        mk=Image.new("L",(W,H),0)
        ImageDraw.Draw(mk).rounded_rectangle([0,0,W-1,H-1],radius=16,fill=255)
        r=Image.new("RGBA",(W,H),(0,0,0,0)); r.paste(img,mask=mk); img=r

        _gold_frame(img); return _to_buf(img)


# ══════════════════════════════════════════════════════════════════
# 싱글톤
# ══════════════════════════════════════════════════════════════════
_renderer: Optional[BG3Renderer] = None

def get_renderer() -> BG3Renderer:
    global _renderer
    if _renderer is None:
        _renderer = BG3Renderer()
    return _renderer
